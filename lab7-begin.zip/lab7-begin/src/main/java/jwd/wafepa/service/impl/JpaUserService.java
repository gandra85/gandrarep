package jwd.wafepa.service.impl;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jwd.wafepa.model.User;
import jwd.wafepa.repository.UserRepository;
import jwd.wafepa.service.UserService;

@Service
@Transactional
public class JpaUserService
implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User findOne(Long id) {
		
		return userRepository.findOne(id);
	}

	@Override
	public List<User> findAll() {
		
		return userRepository.findAll();
	}

	@Override
	public User save(User user) {
		
		return userRepository.save(user);
	}

	@Override
	public User delete(Long id) throws IllegalArgumentException {
		User user = userRepository.findOne(id);
		if(user==null){
			throw new IllegalArgumentException("Tryed to delete non-existing user with id"+id);
		}
		userRepository.delete(id);
		return user;
	}

//	@Override
//	public List<User> findByname(String name) {
//		
//		return userRepository.findByName(name);
//	}

}
