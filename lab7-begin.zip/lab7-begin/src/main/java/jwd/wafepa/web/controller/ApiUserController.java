package jwd.wafepa.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jwd.wafepa.model.User;
import jwd.wafepa.service.UserService;
import jwd.wafepa.web.dto.UserDTO;

@RestController
@RequestMapping(value="/api/users")
public class ApiUserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<List<UserDTO>> getUsers() {
	List<User> users = userService.findAll();
	if(users== null || users.isEmpty()){
		
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	List<UserDTO> usersDTO = new ArrayList<>();
	for(User user : users){
		usersDTO.add(new UserDTO(user));
	}
		return new ResponseEntity<>(usersDTO, HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}")
	public ResponseEntity<UserDTO> getUser(@PathVariable Long id){
		User user = userService.findOne(id);
		if(user==null){
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new UserDTO(user), HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<UserDTO> delete(@PathVariable Long id){
	
		try {
			User user = userService.delete(id);
			return new ResponseEntity<>(new UserDTO(user), HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}	
	}
	
	@RequestMapping(method=RequestMethod.POST, consumes="application/json")
	public ResponseEntity<UserDTO> addUser(@RequestBody UserDTO userDTO){
		User user = new User();
		user.setEmail(userDTO.getEmail());
		user.setFirstname(userDTO.getFirstname());
		user.setLastname(userDTO.getLastname());
		
		
		User userSaved = userService.save(user);
		return new ResponseEntity<>(new UserDTO(userSaved), HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.PUT, consumes="application/json")
	public ResponseEntity<UserDTO> editUser(@RequestBody UserDTO userDTO, @PathVariable Long id){
		if(userDTO==null || userDTO.getId()!=id){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		User user = userService.findOne(id);
		user.setEmail(userDTO.getEmail());
		user.setId(userDTO.getId());
		user.setFirstname(userDTO.getFirstname());
		user.setLastname(userDTO.getLastname());
		
		User savedUser = userService.save(user);
		return new ResponseEntity<>(new UserDTO(savedUser), HttpStatus.OK);
	}
}
