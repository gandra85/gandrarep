var wafepaApp = angular.module('wafepaApp', ['ngRoute']);

wafepaApp.controller('ActivityController', function($scope, $http, $location, $routeParams) {
													//ovo je Angularov dependency injection//
	$scope.getActivities = function() {
		$http.get('api/activities')
				.success(function(data) {
					$scope.activities = data;
					$scope.success= true;
				})
				.error(function() {
					
				});
	};
	
	
	$scope.deleteActivity = function(id){
		$http.delete('api/activities/'+ id)
				.success(function(){
					$scope.getActivities();
				})
				.error(function(){
					
				})
	};
	$scope.initActivity = function(){
		$scope.activity={}; //napravljen novi objekat, sa ng-model="activity.name" se puni objekat	
		$scope.naslov= 'Add activity'
		if($routeParams && $routeParams.id){
			//ovo je edit stranica
			$http.get('api/activities/'+ $routeParams.id)
			.success(function(data){     //ubacuje rezultata sa servera-data moze da se zove kako hocete
				$scope.activity = data;
				$scope.naslov="Edit activity"
			})
			.error(function(){
				
			});
		}else{
			if($routeParams && $routeParams.name){
				//ovo je edit stranica
				$http.get('api/activities/'+ $routeParams.name)
				.success(function(data){     //ubacuje rezultata sa servera-data moze da se zove kako hocete
					$scope.activity = data;
					$scope.naslov="View activity"
					$scope.skriven = true;
					$scope.nemenja = true;
				})
				.error(function(){
					
				});
			}
		}
		
	};
	
	
	
	$scope.saveActivity = function(){
			
		if($scope.activity.id){
			//edit stranica
			$http.put('api/activities/'+ $scope.activity.id, $scope.activity)
			.success(function(){
				$location.path('/activities')
			})
			.error(function(){
				
			});
			
		}else{
			//add stranica
			$http.post('api/activities', $scope.activity) //posalji mu activity
			.success(function(){
				$location.path('/activities')
			})
			.error(function(){
				
			});
	};
		}
		
			
	
});

wafepaApp.controller('UserController', function($scope, $http, $routeParams, $location){
	
	$scope.getUsers = function(){
		$http.get('api/users')
		.success(function(data){
			$scope.users = data;
			$scope.success= true;
		})
		.error(function(){
			
		});
	};
	
	$scope.deleteUsers = function(id){
		$http.delete('api/users/' + id)
		.success(function(){
			$scope.getUsers();
		})
		.error(function(){
			
		});
	};
	
	$scope.initUser = function(){
		$scope.user = {};
		$scope.naslov = 'Add User';
		if($routeParams && $routeParams.id){
			$http.get('api/users/'+ $routeParams.id)
			.success(function(data){
				$scope.user = data;
				$scope.naslov = 'Edit User';
			})
			.error(function(){
				
			});
		}else{
			if($routeParams && $routeParams.email){
				//ovo je edit stranica
				$http.get('api/users/'+ $routeParams.email)
				.success(function(data){     //ubacuje rezultata sa servera-data moze da se zove kako hocete
					$scope.user = data;
					$scope.naslov="View user"
					$scope.skriven = true;
					$scope.nemenja = true;
				})
				.error(function(){
					
				});
			}
		}
	};
	
	$scope.saveUser = function(){
		
		if($scope.user.id){
			//edit stranica
			$http.put('api/users/'+ $scope.user.id, $scope.user)
			.success(function(){
				$location.path('/users')
			})
			.error(function(){
				
			});
			
		}else{
			//add stranica
			$http.post('api/users', $scope.user) //posalji mu activity
			.success(function(){
				$location.path('/users')
			})
			.error(function(){
				
			});
	};
		}
	
});





wafepaApp.config(['$routeProvider', function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl : 'static/html/home.html'
        })
        .when('/activities', {
        	templateUrl : 'static/html/activities.html',
        	controller: 'ActivityController'
        })
        .when('/activities/add', {
        	templateUrl : 'static/html/addEditActivity.html',
        	controller: 'ActivityController'
        })
        .when('/activities/edit/:id', {   //koristi routeParams
        	templateUrl : 'static/html/addEditActivity.html',
        	controller: 'ActivityController'
        })
        .when('/users',{
        	templateUrl : 'static/html/users.html',
        	controller: 'UserController'
        })
        .when('/users/add', {
        	templateUrl : 'static/html/addEditUser.html',
        	controller: 'UserController'
        })
        .when('/users/edit/:id', {   //koristi routeParams
        	templateUrl : 'static/html/addEditUser.html',
        	controller: 'UserController'
        })
         .when('/activities/view/:name', {   //koristi routeParams
        	templateUrl : 'static/html/addEditActivity.html',
        	controller: 'ActivityController'
        })
         .when('/users/view/:email', {   //koristi routeParams
        	templateUrl : 'static/html/addEditUser.html',
        	controller: 'UserController'
        })
        .otherwise({
            redirectTo: '/'
        });
}]);